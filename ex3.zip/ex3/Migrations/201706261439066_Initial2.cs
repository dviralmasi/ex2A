namespace ex3.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial2 : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Ranks", "Wins", c => c.Int(nullable: false));
            AlterColumn("dbo.Ranks", "Losses", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Ranks", "Losses", c => c.String());
            AlterColumn("dbo.Ranks", "Wins", c => c.String());
        }
    }
}
