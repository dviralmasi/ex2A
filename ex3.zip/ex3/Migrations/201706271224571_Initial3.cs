namespace ex3.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial3 : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.Ranks", "Rank");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Ranks", "Rank", c => c.Int(nullable: false));
        }
    }
}
