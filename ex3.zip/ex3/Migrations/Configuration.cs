namespace ex3.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using ex3.Models;
    internal sealed class Configuration : DbMigrationsConfiguration<ex3.Models.UserContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(ex3.Models.UserContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            //    context.People.AddOrUpdate(
            //      p => p.FullName,
            //      new Person { FullName = "Andrew Peters" },
            //      new Person { FullName = "Brice Lambson" },
            //      new Person { FullName = "Rowan Miller" }
            //    );
            //
            context.Ranks.AddOrUpdate(
                new Ranks { ID = "ran", Losses = 1, Wins = 2, Rank = 0},
                new Ranks { ID = "dvir", Losses = 1, Wins = 3, Rank = 0 },
                new Ranks { ID = "hg", Losses = 1, Wins = 0, Rank = 0 }
                );
        }
    }
}
