namespace ex3.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial1 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Ranks",
                c => new
                    {
                        ID = c.String(nullable: false, maxLength: 128),
                        Wins = c.String(),
                        Losses = c.String(),
                        Rank = c.String(),
                    })
                .PrimaryKey(t => t.ID);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Ranks");
        }
    }
}
