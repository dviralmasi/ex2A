﻿$("#login").click(function () {
    //build the user object
    var user = {
        ID: $("#userName").val(),
        Password: $("#password").val()
    };
    //url
    var url = "../api/Users/" + user.ID + "/" + user.Password;
    //call get from server
    $.getJSON(url).done(function (item) {
        alert("You are login!!");
        sessionStorage.setItem("userName", item.ID);
        location.replace("../Home.html");
    }).fail(function(){
        alert("The userName not exist");
        $("#userName").val("");
        $("#password").val("");
    });
});