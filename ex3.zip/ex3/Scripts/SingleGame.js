﻿//start button
var btnStart = document.getElementById("startbtn");
document.getElementById("mazeRows").value = localStorage.getItem("rows");
document.getElementById("mazeCols").value = localStorage.getItem("cols");
if (localStorage.getItem("SearchAlgoDropDown") !== null) {
    //if not null take the value from the localstorage
    if (localStorage.getItem("SearchAlgoDropDown") == "BFS") {
        document.getElementById("SearchAlgoDropDown").selectedIndex = 0;
    }
    if (localStorage.getItem("SearchAlgoDropDown") == "DFS") {
        document.getElementById("SearchAlgoDropDown").selectedIndex = 1;
    }
}
//our object
var board;
var mazeName;
if (btnStart) {
    //add event lisitener
    btnStart.addEventListener("click", function () {
        $(document).ready(function ()
        {
            //take the values from the user
            $("#myLoader").show();
            mazeName = $("#mazeName").val();
            var mazeRows = $("#mazeRows").val();
            var mazeCols = $("#mazeCols").val();
            document.title = mazeName;
            // update the fields in Maze obj
            var generateUrl = "../api/GenerateMaze/GetGenerate/" + mazeName + "/" + mazeRows + "/" + mazeCols;
            $.getJSON(generateUrl, function (data) {
                console.log(data);
                //take images
                var imageStart = document.getElementById("keep-walking");
                var imageEnd = document.getElementById("shampine");
                var win = document.getElementById("win");
                //initalize the board
                board = $("#mazeCanvas").mazeCanvas(data.Maze, data.Start.Row,
                    data.Start.Col, data.End.Row, data.End.Col, data.Rows, data.Cols,
                    imageStart, imageEnd);

                // draw the maze
                board.drawMaze();
                $("#myLoader").hide();
            });
        });
    });
}

//solve option
var btnSolve = document.getElementById("btnSolve");
if (btnSolve) {
    btnSolve.addEventListener("click", function () {
        $(document).ready(function () {
            //choose the alghorithm to solve
            var searchAlgo = $("#SearchAlgoDropDown").val();
            var generateUrl = "../api/GenerateMaze/GetSolveMaze/" + mazeName + "/" + searchAlgo;
            //get from the server the solution
            $.getJSON(generateUrl, function (data) {
                // solve the maze
                board.solveMaze(data.Solution);
            });
        });
    });
}

$(document).keydown(function move(e) {
    if (board) {
        var v = board.moveStep(e);
    }
});




