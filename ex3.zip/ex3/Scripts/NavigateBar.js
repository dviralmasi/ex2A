﻿$("#nav-placeholder").load("../html/NavigateBar.html", function () {
    if (sessionStorage.getItem("userName")) {
        document.getElementById("multi").href = "../html/MultiPlayerGame.html"
        // change register id
        var reg1 = document.getElementById("registerId");
        reg1.textContent = "Hello " + sessionStorage.getItem("userName");
        document.getElementById("registerId").href = "#";
        // change login id
        var reg2 = document.getElementById("loginId");
        reg2.textContent = "Log off";
        reg2.onclick = logOffFunc;
        //go back to home page
        reg2.href = "../Home.html";
    }
});


function logOffFunc() {
    //move out the user from session storage
    sessionStorage.removeItem("userName");
    //change back the text and the attributes
    var reg1 = document.getElementById("registerId");
    reg1.textContent = "Register";
    reg1.href = "../Register.html";
    var reg2 = document.getElementById("loginId");
    reg2.textContent = "Login";
    reg2.onclick = null;
    }