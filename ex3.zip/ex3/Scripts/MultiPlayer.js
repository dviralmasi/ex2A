﻿var board1;
var board2;
var mazeName;

//$(document).ready(function () {
    document.getElementById("mazeRows").value = localStorage.getItem("rows");
    document.getElementById("mazeCols").value = localStorage.getItem("cols");
    var multiPlayerHub = $.connection.multiPlayerHub;

    // draw maze function. the data is the maze we get from Join fucntion
    multiPlayerHub.client.draw = function (data) {
        var imageStart = document.getElementById("keep-walking");
        var imageEnd = document.getElementById("shampine");
        var win = document.getElementById("win");

        // draw in my canvas
        board1 = $("#mazeCanvas1").mazeCanvas(data.Maze, data.Start.Row, data.Start.Col,
            data.End.Row, data.End.Col, data.Rows, data.Cols,
            imageStart, imageEnd);
        board1.drawMaze();

        // draw on opponent
        board2 = $("#mazeCanvas2").mazeCanvas(data.Maze, data.Start.Row, data.Start.Col,
            data.End.Row, data.End.Col, data.Rows, data.Cols,
            imageStart, imageEnd);
        board2.drawMaze();
        $("#myLoader").hide();
    };


    multiPlayerHub.client.moveOneStep = function (direction) {
        if (board2) {
            // do my step
            var lose = board2.moveOpponent(direction);
            if (lose == "g") {
                var player = sessionStorage.userName;
                multiPlayerHub.server.playerLose(player);
            }
        }
    };
    //for list method
    multiPlayerHub.client.showList = function (list) {
        $("#GameListId").html("");
        var dropDownId = document.getElementById("GameListId");
        //for every element in the list
        for (var i = 0; i < list.length; i++) {
            var option = document.createElement("option");
            option.text = list[i];
            //add to dropDown
            dropDownId.add(option);
        }
    };
    //when click make list
    $.connection.hub.start().done(function () {

        //start game option
        $("#startbtn").click(function () {
            $("#myLoader").show();
            mazeName = $("#mazeName").val();
            var mazeRows = $("#mazeRows").val();
            var mazeCols = $("#mazeCols").val();
            document.title = mazeName;
            // update the fields in Maze obj
            multiPlayerHub.server.connect(mazeName);
            multiPlayerHub.server.startGame(mazeName, mazeRows, mazeCols);
        });

        $("#GameListId").click(function () {
            multiPlayerHub.server.listGame();
        });

        //join to game option
        $("#joinId").click(function () {
            var nameToJoin = $("#GameListId").val();
            multiPlayerHub.server.joinGame(nameToJoin);
            document.title = nameToJoin;
        });
        //for moving the current player
        $(document).keydown(function move(e) {
            if (board1) {
                // do my step
                var win = board1.moveStep(e); 
                if (win == "h") {
                    //get the name from the session storage
                    var player = sessionStorage.userName;
                    multiPlayerHub.server.playerWon(player);
                }
             
                // move step in opponent screen
                var direction;
                switch (e.which) {
                    case 37:
                        direction = "left";
                        break;
                    case 38:
                        direction = "up";
                        break;
                    case 39:
                        direction = "right";
                        break;
                    case 40:
                        direction = "down";
                        break;
                    default: direction = null;
                        break;
                }
                //call play game
                if (direction) {
                    multiPlayerHub.server.playGame(direction);
                }
            }
        });

    });
//});


