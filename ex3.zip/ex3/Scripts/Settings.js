﻿(function ($) {
    $(document).ready(function () {
        if (localStorage.getItem("rows") !== null) {
            //if not null take the value from the localstorage
            document.getElementById("rows").value = localStorage.getItem("rows");
        }
        if (localStorage.getItem("cols") !== null) {
            //if not null take the value from the localstorage
            document.getElementById("cols").value = localStorage.getItem("cols");
        }
        if (localStorage.getItem("SearchAlgoDropDown") !== null) {
            //if not null take the value from the localstorage
            if (localStorage.getItem("SearchAlgoDropDown") == "BFS") {
                document.getElementById("SearchAlgoDropDown").selectedIndex = 0;
            }
            if (localStorage.getItem("SearchAlgoDropDown") == "DFS") {
                document.getElementById("SearchAlgoDropDown").selectedIndex = 1;
            }
        }
    });
    //on click on ok take take the val into the local storage
    $("#Setting").click(function () {
        localStorage.rows = $("#rows").val();
        localStorage.cols = $("#cols").val();
        localStorage.SearchAlgoDropDown = $("#SearchAlgoDropDown").val();
    });

})(jQuery);