﻿
function checkName() {
    var name = $("#usr").val();

    var registerUrl = "/api/Users/" + name;
    $.getJSON(registerUrl, function (item) {
        if (item) {
            alert("The name is already exist");
            $("#usr").val("");
        }
        
    });
};


function checkPassword() {
    var password = $("#psw").val();
    var rePassword = $("#psw-repeat").val();
    if (password != rePassword) {
        alert("Wrong password");
        $("#psw-repeat").val("");
    }

};

$("#signUp").click(function () {
    //build the user
    var user = {
        ID: $("#usr").val(),
        Password: $("#psw").val(),
        Email: $("#email").val()
    };
    //call post to server
    var registerUrl = "../api/Users";
    $.post(registerUrl, user).done(function () {
        location.replace("../Home.html");
    }).fail(function () {
        alert("can't register!");
        var u = document.getElementById("signUp");
    });
});