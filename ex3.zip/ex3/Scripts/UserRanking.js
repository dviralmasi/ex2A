﻿var ViewModel = function () {
    var self = this; // make 'this' available to subfunctions or closures
    self.Ranks = ko.observableArray(); // enables data binding
    var ranksUri = "/api/Ranks";
    function getAllRanks() {
        $.getJSON(ranksUri).done(function (data) {
            //get the length of the table
            var length = data.length;
            var i = 1;
            data.forEach(function (user) {
                user["Rank"] = i
                i++;
            });
            self.Ranks(data);
        });
    }
    // Fetch the initial data
    getAllRanks();
};
ko.applyBindings(new ViewModel()); // sets up the data binding 