﻿
$(document).ready(function () {
    var script = document.createElement('script');
    //link to js
    script.src = "../Scripts/CanvasMazePlugin.js";
    document.getElementsByTagName('head')[0].appendChild(script);
    //timer for the dispathcher
    var timer;
    //index
    var i = 0;
    //image for start location
    var imgStart;
    (function ($) {
        //values
        $.fn.mazeCanvas = function (mazeData, startRow, startCol, exitRow, exitCol, rows, cols, imageStart, imageEnd) {
            var context;
            var arr;
            var cellHeight;
            var cellWidth;
            var currentRow;
            var currentCol;
            var myCanvas = this[0];
             imgStart = imageStart;
             var imgEnd = imageEnd;
             var winImage = win;
            currentRow = startRow;
            currentCol = startCol;
            //build the object of board
            var board = {
                //in board we can draw the maze
                drawMaze: function () {
                    // convert string to array
                    arr = Array.from(mazeData);
                    context = myCanvas.getContext("2d");
                    //calculate the width and the height
                    cellWidth = myCanvas.width / cols;
                    cellHeight = myCanvas.height / rows;
                    var myCallbackFunc = this.callbackFunc;
                    // clear the board
                    context.clearRect(0, 0, myCanvas.width, myCanvas.height);
                    // start point
                    context.drawImage(imageStart, startCol * cellWidth, startRow * cellHeight, cellWidth, cellHeight);
                    // end point
                    context.drawImage(imageEnd, exitCol * cellWidth, exitRow * cellHeight, cellWidth, cellHeight);
                    for (var i = 0; i < rows; i++) {
                        for (var j = 0; j < cols; j++) {
                            if (arr[i * cols + j] == '1') {
                                context.fillRect(cellWidth * j, cellHeight * i,
                                    cellWidth, cellHeight);
                            }
                        }
                    }
                },
                
                // move step according the arrow keys
                moveStep: function (direction){
                    var myMove;
                    //switch of the direction given
                    switch (direction.which) {
                        case 37:
                            // left
                            myMove = "left";
                            if (arr[currentRow * cols + (currentCol - 1)] == '1' || (currentCol - 1) < 0) {
                                break;
                            }
                            drawPictureLeft(context, currentCol, currentRow, imageStart, cellWidth, cellHeight);
                            //context.drawImage(imageStart, (currentCol - 1) * cellWidth, currentRow * cellHeight, cellWidth, cellHeight);
                            //context.clearRect((currentCol) * cellWidth, currentRow * cellHeight, cellWidth, cellHeight);
                            //update the right field
                            currentCol--;
                            //end game    
                            if (currentRow == exitRow && currentCol == exitCol) {
                               // alert("you Win!");
                                var winImg = document.getElementById("win");
                                context.drawImage(winImg, myCanvas.width / 6, myCanvas.height / 3, 400, 300);
                                setTimeout(function () {
                                    window.location.replace("../Home.html");
                                }, 2000);   
                                return "h";
                            }
                            //myCallbackFunc("left", currentRow, currentCol);
                            break;
                        case 38:
                            // Up
                            myMove = "up";
                            if (arr[(currentRow - 1) * cols + currentCol] == '1' || (currentRow - 1) < 0) {
                                break;
                            }
                            drawPictureUp(context, currentCol, currentRow, imageStart, cellWidth, cellHeight);
                            //context.drawImage(imageStart, currentCol * cellWidth, (currentRow - 1) * cellHeight, cellWidth, cellHeight);
                            //context.clearRect(currentCol * cellWidth, (currentRow) * cellHeight, cellWidth, cellHeight);
                            //update the right field
                            currentRow--;
                            //end game
                            if (currentRow == exitRow && currentCol == exitCol) {
                                var winImg = document.getElementById("win");
                                context.drawImage(winImg, myCanvas.width / 6, myCanvas.height / 3, 400, 300);
                              //  alert("you Win!");
                                setTimeout(function () {
                                    window.location.replace("../Home.html");
                                }, 2000);   
                                return "h";
                            }
                            break;
                        case 39:
                            // Right
                            myMove = "right";
                            if (arr[currentRow * cols + (currentCol + 1)] == '1' || (currentCol + 1) >= cols) {
                                break;
                            }
                            drawPictureRight(context, currentCol, currentRow, imageStart, cellWidth, cellHeight);
                            //context.drawImage(imageStart, (currentCol + 1) * cellWidth, currentRow * cellHeight, cellWidth, cellHeight);
                            //context.clearRect((currentCol) * cellWidth, currentRow * cellHeight, cellWidth, cellHeight);
                            //update the right field
                            currentCol++;
                            //end game
                            if (currentRow == exitRow && currentCol == exitCol) {
                                var winImg = document.getElementById("win");
                                context.drawImage(winImg, myCanvas.width / 6, myCanvas.height / 3, 400, 300);
                                setTimeout(function () {
                                    window.location.replace("../Home.html");
                                }, 2000);   
                                return "h";
                            }
                            break;
                        case 40:
                            // Down
                            myMove = "down";
                            if (arr[(currentRow + 1) * cols + currentCol] == '1' || (currentRow + 1) >= rows) {
                                break;
                            }
                            drawPictureDown(context, currentCol, currentRow, imageStart, cellWidth, cellHeight);
                            //context.drawImage(imageStart, currentCol * cellWidth, (currentRow + 1) * cellHeight, cellWidth, cellHeight);
                            //context.clearRect(currentCol * cellWidth, currentRow * cellHeight, cellWidth, cellHeight);
                            //update the right field
                            currentRow++;
                            if (currentRow == exitRow && currentCol == exitCol) {
                                //end game
                                var winImg = document.getElementById("win");
                                context.drawImage(winImg, myCanvas.width / 6, myCanvas.height / 3, 400, 300);
                                setTimeout(function () {
                                    window.location.replace("../Home.html");
                                }, 2000);   
                                return "h";
                            }
                            break;
                        default: return;
                    }
                },

                moveOpponent: function (direction) {
                    // direction is string
                    switch (direction) {
                        case "left":
                            // left
                            if (arr[currentRow * cols + (currentCol - 1)] == '1' || (currentCol - 1) < 0) {
                                break;
                            }
                            context.drawImage(imageStart, (currentCol - 1) * cellWidth, currentRow * cellHeight, cellWidth, cellHeight);
                            context.clearRect((currentCol) * cellWidth, currentRow * cellHeight, cellWidth, cellHeight);
                            //update the right field
                            currentCol--;
                            if (currentRow == exitRow && currentCol == exitCol) {
                                //end game
                                var loseImg = document.getElementById("lose");
                                context.drawImage(loseImg, myCanvas.width /6 , myCanvas.height / 3, 400, 300);
                                setTimeout(function () {
                                    window.location.replace("../Home.html");
                                }, 2000);
                                return "g";
                            }
                            break;
                        case "up":
                            // Up
                            if (arr[(currentRow - 1) * cols + currentCol] == '1' || (currentRow - 1) < 0) {
                                break;
                            }
                            context.drawImage(imageStart, currentCol * cellWidth, (currentRow - 1) * cellHeight, cellWidth, cellHeight);
                            context.clearRect(currentCol * cellWidth, (currentRow) * cellHeight, cellWidth, cellHeight);
                            //update the right field
                            currentRow--;
                            if (currentRow == exitRow && currentCol == exitCol) {
                                //end game
                                var loseImg = document.getElementById("lose");
                                context.drawImage(loseImg, myCanvas.width /6 , myCanvas.height / 3, 400, 300);
                                setTimeout(function () {
                                    window.location.replace("../Home.html");
                                }, 2000);
                                return "g";
                            }
                            break;
                        case "right":
                            // Right
                            if (arr[currentRow * cols + (currentCol + 1)] == '1' || (currentCol + 1) >= cols) {
                                break;
                            }
                            context.drawImage(imageStart, (currentCol + 1) * cellWidth, currentRow * cellHeight, cellWidth, cellHeight);
                            context.clearRect((currentCol) * cellWidth, currentRow * cellHeight, cellWidth, cellHeight);
                            //update the right field
                            currentCol++;
                            //end game
                            if (currentRow == exitRow && currentCol == exitCol) {
                                var loseImg = document.getElementById("lose");
                                context.drawImage(loseImg, myCanvas.width / 6, myCanvas.height / 3, 400, 300);
                                setTimeout(function () {
                                    window.location.replace("../Home.html");
                                }, 2000);
                                return "g";
                            }
                            break;
                        case "down":
                            // Down
                            if (arr[(currentRow + 1) * cols + currentCol] == '1' || (currentRow + 1) >= rows) {
                                break;
                            }
                            context.drawImage(imageStart, currentCol * cellWidth, (currentRow + 1) * cellHeight, cellWidth, cellHeight);
                            context.clearRect(currentCol * cellWidth, currentRow * cellHeight, cellWidth, cellHeight);
                            //update the right field
                            currentRow++;
                            //end game
                            if (currentRow == exitRow && currentCol == exitCol) {
                                var loseImg = document.getElementById("lose");
                                context.drawImage(loseImg, myCanvas.width / 6, myCanvas.height / 3, 400, 300);
                                setTimeout(function () {
                                    window.location.replace("../Home.html");
                                }, 2000);
                                return "g";
                            }
                            break;
                        default: break;
                    }
                },
                // solve maze function
                solveMaze: function (solution) {
                    arrSolution = Array.from(solution);
                    // first, draw the image in start point
                    context.clearRect(currentCol * cellWidth, currentRow * cellHeight, cellWidth, cellHeight);
                    currentCol = startCol;
                    currentRow = startRow;
                    context.drawImage(imageStart, currentCol * cellWidth, currentRow * cellHeight, cellWidth, cellHeight);
                    // i = 0;
                    //direction = arrSolution[i];
                    size = arrSolution.length;
                    timer = setInterval(function () {
                        direction = arrSolution[i];
                            // anyway, clear the prev image on the canvas
                            context.clearRect(currentCol * cellWidth, currentRow * cellHeight, cellWidth, cellHeight);
                            if (direction == "0") {
                                // left
                                currentCol--;
                            }

                            if (direction == "1") {
                                // right
                                currentCol++;
                            }

                            if (direction == "2") {
                                // up
                                currentRow--;
                            }

                            if (direction == "3") {
                                // down
                                currentRow++;

                            }
                            context.drawImage(imgStart, currentCol * cellWidth, (currentRow) * cellHeight, cellWidth, cellHeight);

                            if (i < size) {
                                i++;
                            } else {
                                clearInterval(timer);
                                // replace to home page 
                                var winImg = document.getElementById("win");
                                context.drawImage(winImg, myCanvas.width / 6, myCanvas.height / 3, 400, 300);
                                setTimeout(function () {
                                    window.location.replace("../Home.html");
                                }, 2000);
                            }

                        
                    }, 500);
                }
            };
            return board;
        }

    })(jQuery);
});

function drawPictureLeft(context, currentCol, currentRow, imageStart, cellWidth, cellHeight) {
    context.drawImage(imageStart, (currentCol - 1) * cellWidth, currentRow * cellHeight, cellWidth, cellHeight);
    context.clearRect((currentCol) * cellWidth, currentRow * cellHeight, cellWidth, cellHeight);
};

function drawPictureUp(context, currentCol, currentRow, imageStart, cellWidth, cellHeight) {
    context.drawImage(imageStart, currentCol * cellWidth, (currentRow-1) * cellHeight, cellWidth, cellHeight);
    context.clearRect((currentCol) * cellWidth, currentRow * cellHeight, cellWidth, cellHeight);
};

function drawPictureRight(context, currentCol, currentRow, imageStart, cellWidth, cellHeight) {
    context.drawImage(imageStart, (currentCol + 1) * cellWidth, currentRow * cellHeight, cellWidth, cellHeight);
    context.clearRect((currentCol) * cellWidth, currentRow * cellHeight, cellWidth, cellHeight);
};

function drawPictureDown(context, currentCol, currentRow, imageStart, cellWidth, cellHeight) {
    context.drawImage(imageStart, (currentCol) * cellWidth, (currentRow+1) * cellHeight, cellWidth, cellHeight);
    context.clearRect((currentCol) * cellWidth, currentRow * cellHeight, cellWidth, cellHeight);
};