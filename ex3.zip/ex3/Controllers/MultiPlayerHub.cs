﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;
using ex3.Models;
using Newtonsoft.Json.Linq;
using MazeLib;
using System.Collections.Concurrent;

namespace ex3.Controllers
{
    /// <summary>
    /// Class MultiPlayerHub.
    /// </summary>
    /// <seealso cref="Microsoft.AspNet.SignalR.Hub" />
    public class MultiPlayerHub : Hub
    {
        /// <summary>
        /// The model
        /// </summary>
        private static IModel model = new Model();
        /// <summary>
        /// The database
        /// </summary>
        private UserContext db = new UserContext();
        /// <summary>
        /// The users list
        /// </summary>
        private static ConcurrentDictionary<string, string> usersList =
            new ConcurrentDictionary<string, string>();

        /// <summary>
        /// Connects the specified name.
        /// </summary>
        /// <param name="name">The name.</param>
        public void Connect(string name)
        {
            usersList[name] = Context.ConnectionId;
        }

        /// <summary>
        /// Lists the game.
        /// </summary>
        public void ListGame()
        {
            List<string> gameList = model.ListGame();
            Clients.Caller.showList(gameList);        
        }

        /// <summary>
        /// Starts the game.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="myRows">My rows.</param>
        /// <param name="myCols">My cols.</param>
        public void StartGame(string name, string myRows, string myCols)
        {
            int rows = Int32.Parse(myRows);
            int cols = Int32.Parse(myCols);
            string nameHosttId = usersList[name];
            if (nameHosttId == null)
                return;
            model.startGame(nameHosttId, name, rows, cols);
        }

        /// <summary>
        /// Joins the game.
        /// </summary>
        /// <param name="nameJoin">The name join.</param>
        public void JoinGame(string nameJoin)
        {
            //string nameGuestId = usersList[nameJoin];
           // if (nameGuestId == null)
            //    return;
            MultiPlayerGame multiGame = model.JoinToGame(Context.ConnectionId, nameJoin);
            string hostId = multiGame.getHost();
            JObject mazeObj = JObject.Parse(multiGame.getMaze().ToJSON());
            Clients.Caller.draw(mazeObj);
            Clients.Client(hostId).draw(mazeObj);
        }

        /// <summary>
        /// Plays the game.
        /// </summary>
        /// <param name="direction">The direction.</param>
        public void PlayGame(string direction)
        {
            string callerId = Context.ConnectionId;
            MultiPlayerGame currentGame = model.PlayGame(callerId);
            string opponentId = currentGame.getOtherClient(callerId);
            Clients.Client(opponentId).moveOneStep(direction);
        }

        /// <summary>
        /// Players the won.
        /// </summary>
        /// <param name="playerName">Name of the player.</param>
        public void PlayerWon(string playerName)
        {
            //User usr = db.Users.Find(playerName);
            Ranks winner = db.Ranks.Where(user1 => user1.ID == playerName).FirstOrDefault();
                winner.Wins++;
            db.SaveChanges();
           // Clients.Caller.getBack();
        }

        /// <summary>
        /// Players the lose.
        /// </summary>
        /// <param name="playerName">Name of the player.</param>
        public void PlayerLose(string playerName)
        {
            //User usr = db.Users.Find(playerName);
            Ranks Loser = db.Ranks.Where(user1 => user1.ID == playerName).FirstOrDefault();
            Loser.Losses++;
            db.SaveChanges();
            //Clients.Caller.getBack();
        }
    }
}