﻿using ex3.Models;
using MazeLib;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ex3.Controllers
{
    /// <summary>
    /// Class GenerateMazeController.
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    public class GenerateMazeController : ApiController
    {
        /// <summary>
        /// The model
        /// </summary>
        private static IModel model = new Model();

        // GET: api/GenerateMaze
        /// <summary>
        /// Gets this instance.
        /// </summary>
        /// <returns>IEnumerable&lt;System.String&gt;.</returns>
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/GenerateMaze/5
        /// <summary>
        /// Gets the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>System.String.</returns>
        public string Get(int id)
        {
            return "value";
        }

        /// <summary>
        /// Gets the generate.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="rows">The rows.</param>
        /// <param name="cols">The cols.</param>
        /// <returns>JObject.</returns>
        [HttpGet]
        [Route("api/GenerateMaze/GetGenerate/{name}/{rows}/{cols}")]
        public JObject GetGenerate(string name, int rows, int cols)
        {
            Maze maze = model.generateMaze(name, rows, cols);
            JObject obj = JObject.Parse(maze.ToJSON());
            return obj;
        }

        /// <summary>
        /// Gets the solve maze.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="algorithm">The algorithm.</param>
        /// <returns>JObject.</returns>
        [HttpGet]
        [Route("api/GenerateMaze/GetSolveMaze/{name}/{algorithm}")]
        public JObject GetSolveMaze(string name, string algorithm)
        {
            int intAlgo;
            if (algorithm.Equals("BFS"))
            {
                intAlgo = 0;
            }
            else
            {
                intAlgo = 1;
            }
            string sol = model.solveMaze(name, intAlgo);

            JObject obj = JObject.Parse(sol);
            return obj;
        }

        // POST: api/GenerateMaze
        /// <summary>
        /// Posts the specified value.
        /// </summary>
        /// <param name="value">The value.</param>
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/GenerateMaze/5
        /// <summary>
        /// Puts the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="value">The value.</param>
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/GenerateMaze/5
        /// <summary>
        /// Deletes the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        public void Delete(int id)
        {
        }
    }
}
