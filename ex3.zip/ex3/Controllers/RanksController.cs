﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using ex3.Models;

namespace ex3.Controllers
{
    /// <summary>
    /// Class RanksController.
    /// </summary>
    /// <seealso cref="System.Web.Http.ApiController" />
    public class RanksController : ApiController
    {
        /// <summary>
        /// The database
        /// </summary>
        private UserContext db = new UserContext();

        // GET: api/Ranks
        /// <summary>
        /// Gets the ranks.
        /// </summary>
        /// <returns>IQueryable&lt;Ranks&gt;.</returns>
        public IQueryable<Ranks> GetRanks()
        {
            return db.Ranks.OrderByDescending(u =>(u.Wins - u.Losses));
        }

        // GET: api/Ranks/5
        /// <summary>
        /// Gets the ranks.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>Task&lt;IHttpActionResult&gt;.</returns>
        [ResponseType(typeof(Ranks))]
        public async Task<IHttpActionResult> GetRanks(string id)
        {
            Ranks ranks = await db.Ranks.FindAsync(id);
            if (ranks == null)
            {
                return NotFound();
            }

            return Ok(ranks);
        }

        // PUT: api/Ranks/5
        /// <summary>
        /// Puts the ranks.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="ranks">The ranks.</param>
        /// <returns>Task&lt;IHttpActionResult&gt;.</returns>
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutRanks(string id, Ranks ranks)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != ranks.ID)
            {
                return BadRequest();
            }

            db.Entry(ranks).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RanksExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Ranks
        /// <summary>
        /// Posts the ranks.
        /// </summary>
        /// <param name="ranks">The ranks.</param>
        /// <returns>Task&lt;IHttpActionResult&gt;.</returns>
        [ResponseType(typeof(Ranks))]
        public async Task<IHttpActionResult> PostRanks(Ranks ranks)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Ranks.Add(ranks);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (RanksExists(ranks.ID))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = ranks.ID }, ranks);
        }

        // DELETE: api/Ranks/5
        /// <summary>
        /// Deletes the ranks.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>Task&lt;IHttpActionResult&gt;.</returns>
        [ResponseType(typeof(Ranks))]
        public async Task<IHttpActionResult> DeleteRanks(string id)
        {
            Ranks ranks = await db.Ranks.FindAsync(id);
            if (ranks == null)
            {
                return NotFound();
            }

            db.Ranks.Remove(ranks);
            await db.SaveChangesAsync();

            return Ok(ranks);
        }

        /// <summary>
        /// Releases the unmanaged resources that are used by the object and, optionally, releases the managed resources.
        /// </summary>
        /// <param name="disposing">true to release both managed and unmanaged resources; false to release only unmanaged resources.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary>
        /// Rankses the exists.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        private bool RanksExists(string id)
        {
            return db.Ranks.Count(e => e.ID == id) > 0;
        }
    }
}