﻿using MazeLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;

namespace ex3.Models
{

    /// <summary>
    /// multiplayer class
    /// </summary>
    public class MultiPlayerGame
    {
        /// <summary>
        /// host client
        /// </summary>
        private string hostId;
        /// <summary>
        /// guest client
        /// </summary>
        private string guestId;
        /// <summary>
        /// my maze
        /// </summary>
        private Maze maze;
        /// <summary>
        /// check if partner is ready yet
        /// </summary>
        private bool partnerReady = false;

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="myHost">with host</param>
        /// <param name="maze">my maze</param>
        public MultiPlayerGame(string myHost, Maze maze)
        {
            this.hostId = myHost;
            this.maze = maze;
        }
        /// <summary>
        /// wait for guest to connect
        /// </summary>
        public void waitForGuest()
        {
            while (!partnerReady)
            {
                Thread.Sleep(100);
            }
        }
        /// <summary>
        /// set the guest
        /// </summary>
        /// <param name="joinClient">the guest</param>
        public void setGuest(string joinClient)
        {
            guestId = joinClient;
            partnerReady = true;
        }
        /// <summary>
        /// set partner is ready to true
        /// </summary>
        public void setPartnerIsReady()
        {
            partnerReady = true;
        }
        /// <summary>
        /// get maze
        /// </summary>
        /// <returns>my maze</returns>
        public Maze getMaze()
        {
            return maze;
        }
        /// <summary>
        /// get host
        /// </summary>
        /// <returns>host</returns>
        public string getHost()
        {
            return hostId;
        }
        /// <summary>
        /// get guest
        /// </summary>
        /// <returns>guest</returns>
        public string getGuest()
        {
            return guestId;
        }
        /// <summary>
        /// find the other client
        /// </summary>
        /// <param name="client">self</param>
        /// <returns>my partner</returns>
        public string getOtherClient(string client)
        {
            if (hostId == client)
                return guestId;
            return hostId;
        }
    }
}