﻿using MazeGeneratorLib;
using MazeLib;
using Newtonsoft.Json.Linq;
using SearchAlgorithmsLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace ex3.Models
{

    /// <summary>
    /// class model implement imodel
    /// </summary>
    /// <seealso cref="ex3.Models.IModel" />
    public class Model : IModel
    {
        /// <summary>
        /// pool of regular maze
        /// </summary>
        private Dictionary<string, Maze> poolMaze;
        /// <summary>
        /// solution cache
        /// </summary>
        private Dictionary<string, Solution<Position>> solutionCache;
        /// <summary>
        /// pool of game we can to join them
        /// </summary>
        private Dictionary<string, MultiPlayerGame> poolGameToJoin;
        /// <summary>
        /// all active game
        /// </summary>
        private Dictionary<string, MultiPlayerGame> allActivePoolGame;
        /// <summary>
        /// constructor
        /// </summary>
        public Model()
        {
            poolMaze = new Dictionary<string, Maze>();
            solutionCache = new Dictionary<string, Solution<Position>>();
            poolGameToJoin = new Dictionary<string, MultiPlayerGame>();
            allActivePoolGame = new Dictionary<string, MultiPlayerGame>();
        }
        /// <summary>
        /// generate maze
        /// </summary>
        /// <param name="name">name</param>
        /// <param name="rows">rows</param>
        /// <param name="cols">cols</param>
        /// <returns>new maze</returns>
        public Maze generateMaze(string name, int rows, int cols)
        {
            DFSMazeGenerator mazeCreator = new DFSMazeGenerator();
            Maze maze = mazeCreator.Generate(rows, cols);
            maze.Name = name;
            poolMaze.Add(maze.Name, maze);
            return maze;
        }
        /// <summary>
        /// get solution cache
        /// </summary>
        /// <returns>dictionary</returns>
        public Dictionary<string, Solution<Position>> getSolutionCache()
        {
            return solutionCache;
        }

        /// <summary>
        /// solve maze
        /// </summary>
        /// <param name="name">name to solve</param>
        /// <param name="algoChoose">solve with...</param>
        /// <returns>solution</returns>
        public string solveMaze(string name, int algoChoose)
        {
            // check if the solution is already exist..
            if (solutionCache.ContainsKey(name))
            {
                Solution<Position> sol = solutionCache[name];
                return ConvertSolutionToJson(name, sol);
            }
            // check if we need caculste dfs or bfs
            if (algoChoose == 1)
            {
                // dfs
                if (poolMaze.ContainsKey(name))
                {
                    Maze maze = poolMaze[name];
                    MazeSearcher mazeSearchable = new MazeSearcher(maze);
                    Searcher<Position> dfsAlgo = new Dfs<Position>();
                    Solution<Position> sol1 = dfsAlgo.search(mazeSearchable);
                    sol1.setEvaluatedNodes(dfsAlgo.getNumberOfNodesEvaluated());
                    solutionCache.Add(name, sol1);
                    string solve = ConvertSolutionToJson(name, sol1);
                    return solve;
                }
                else
                {
                    Console.WriteLine("Error in poolMaze request");
                    return null;
                }
            }
            else
            {
                // bfs
                if (poolMaze.ContainsKey(name))
                {
                    Maze maze = poolMaze[name];
                    MazeSearcher mazeSearchable = new MazeSearcher(maze);
                    Searcher<Position> bfsAlgo = new Bfs<Position>();
                    Solution<Position> sol2 = bfsAlgo.search(mazeSearchable);
                    sol2.setEvaluatedNodes(bfsAlgo.getNumberOfNodesEvaluated());
                    solutionCache.Add(name, sol2);
                    string solve = ConvertSolutionToJson(name, sol2);
                    return solve;
                }
                else
                {
                    Console.WriteLine("Error in poolMaze request");
                    return null;
                }
            }
        }

        /// <summary>
        /// Converts the solution to json.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="sol">The sol.</param>
        /// <returns>System.String.</returns>
        public string ConvertSolutionToJson(string name, Solution<Position> sol)
        {
            dynamic solveJson = new JObject();
            solveJson.Name = name;
            solveJson.Solution = CalculateSteps(sol);
            solveJson.NodesEvaluated = sol.getNumberOfNodesEvaluated().ToString();
            return solveJson.ToString();
        }

        /// <summary>
        /// Calculates the steps.
        /// </summary>
        /// <param name="sol">The sol.</param>
        /// <returns>System.String.</returns>
        public string CalculateSteps(Solution<Position> sol)
        {
            // string object for adding string each time
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < sol.getList().Count - 1; i++)
            {
                // i move left
                if (sol.getList()[i].getState().Col > sol.getList()[i + 1].getState().Col)
                {
                    sb.Append("0");
                    continue;
                }
                // i move right
                if (sol.getList()[i].getState().Col < sol.getList()[i + 1].getState().Col)
                {
                    sb.Append("1");
                    continue;
                }
                // i move up
                if (sol.getList()[i].getState().Row > sol.getList()[i + 1].getState().Row)
                {
                    sb.Append("2");
                    continue;
                }
                // i move down
                if (sol.getList()[i].getState().Row < sol.getList()[i + 1].getState().Row)
                {
                    sb.Append("3");
                    continue;
                }
            }
            return sb.ToString();
        }

        /// <summary>
        /// for start action
        /// </summary>
        /// <param name="idConnectionHost">The identifier connection host.</param>
        /// <param name="name">name of the game</param>
        /// <param name="rows">rows</param>
        /// <param name="cols">col</param>
        public void startGame(string idConnectionHost, string name, int rows, int cols)
        {
            Maze maze;
            // check if we have exist maze, if not -create new one
            if (poolMaze.ContainsKey(name))
            {
                maze = poolMaze[name];
            }
            else
            {
                maze = generateMaze(name, rows, cols);
            }
            //make a multi game
            MultiPlayerGame multiGame = new MultiPlayerGame(idConnectionHost, maze);
            poolGameToJoin.Add(maze.Name, multiGame);
            //wait
            multiGame.waitForGuest();
        }

        /// <summary>
        /// list action
        /// </summary>
        /// <returns>list of game to join</returns>
        public List<string> ListGame()
           {
            List<string> gameList = new List<string>(this.poolGameToJoin.Keys);
            return gameList;
           }

        /// <summary>
        /// join action
        /// </summary>
        /// <param name="guestId">The guest identifier.</param>
        /// <param name="name">name of game to join</param>
        /// <returns>MultiPlayerGame.</returns>
        public MultiPlayerGame JoinToGame(string guestId, string name)
           {
               //find
               if (poolGameToJoin.ContainsKey(name))
               {
                   //get
                   MultiPlayerGame multiGame = poolGameToJoin[name];
                   //set
                   multiGame.setGuest(guestId);
                   //Maze mazeToJoin = poolGameToJoin[name].getMaze();
                   allActivePoolGame.Add(name, multiGame);
                   poolGameToJoin.Remove(name);
                   return multiGame;
               }
               // else
               Console.WriteLine("server - there is no free player to play");
               return null;
           }

        /// <summary>
        /// play action
        /// </summary>
        /// <param name="clientId">The client identifier.</param>
        /// <returns>the game he playes at</returns>
        public MultiPlayerGame PlayGame(string clientId)
           {
               //find the game
               foreach (KeyValuePair<string, MultiPlayerGame> tuple in allActivePoolGame)
               {
                   if (tuple.Value.getHost() == clientId)
                   {
                       return tuple.Value;
                   }
                   if (tuple.Value.getGuest() == clientId)
                   {
                       return tuple.Value;
                   }
               }
               Console.WriteLine("MultiPlayerGame not found 404");
               return null;
           }
        
        /*
           /// <summary>
           /// close action
           /// </summary>
           /// <param name="client">current client</param>
           /// <param name="nameToClose">game to close</param>
           /// <returns>the game</returns>
           public MultiPlayerGame closeGame(TcpClient client, string nameToClose)
           {
               MultiPlayerGame multiGameToDelete;
               //find
               foreach (KeyValuePair<string, MultiPlayerGame> tuple in allActivePoolGame)
               {
                   if (tuple.Value.getHost() == client)
                   {
                       multiGameToDelete = tuple.Value;
                       allActivePoolGame.Remove(tuple.Key);
                       return multiGameToDelete;
                   }
                   if (tuple.Value.getGuest() == client)
                   {
                       multiGameToDelete = tuple.Value;
                       allActivePoolGame.Remove(tuple.Key);
                       return multiGameToDelete;
                   }
               }
               Console.WriteLine("MultiPlayerGame not found 404");
               return null;
           }
       }
   }*/





    }
}