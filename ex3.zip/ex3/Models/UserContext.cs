﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace ex3.Models
{
    /// <summary>
    /// Class UserContext.
    /// </summary>
    /// <seealso cref="System.Data.Entity.DbContext" />
    public class UserContext : DbContext
    {
        // You can add custom code to this file. Changes will not be overwritten.
        // 
        // If you want Entity Framework to drop and regenerate your database
        // automatically whenever you change your model schema, please use data migrations.
        // For more information refer to the documentation:
        // http://msdn.microsoft.com/en-us/data/jj591621.aspx

        /// <summary>
        /// Initializes a new instance of the <see cref="UserContext"/> class.
        /// </summary>
        public UserContext() : base("name=UserContext")
        {
        }

        /// <summary>
        /// Gets or sets the users.
        /// </summary>
        /// <value>The users.</value>
        public System.Data.Entity.DbSet<ex3.Models.User> Users { get; set; }

        /// <summary>
        /// Gets or sets the ranks.
        /// </summary>
        /// <value>The ranks.</value>
        public System.Data.Entity.DbSet<ex3.Models.Ranks> Ranks { get; set; }
    }
}
