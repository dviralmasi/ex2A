﻿using MazeLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex3.Models
{

    /// <summary>
    /// Interface IModel
    /// </summary>
    public interface IModel
    {
        /// <summary>
        /// generate action
        /// </summary>
        /// <param name="name">name</param>
        /// <param name="rows">rows</param>
        /// <param name="cols">cols</param>
        /// <returns>new maze</returns>
        Maze generateMaze(string name, int rows, int cols);
        /// <summary>
        /// solve action
        /// </summary>
        /// <param name="name">name</param>
        /// <param name="algoChoose">algo</param>
        /// <returns>solution</returns>
        string solveMaze(string name, int algoChoose);

        /// <summary>
        /// Starts the game.
        /// </summary>
        /// <param name="idConnectionHost">The identifier connection host.</param>
        /// <param name="name">The name.</param>
        /// <param name="rows">The rows.</param>
        /// <param name="cols">The cols.</param>
        void startGame(string idConnectionHost, string name, int rows, int cols);
        /// <summary>
        /// Joins to game.
        /// </summary>
        /// <param name="guestId">The guest identifier.</param>
        /// <param name="name">The name.</param>
        /// <returns>MultiPlayerGame.</returns>
        MultiPlayerGame JoinToGame(string guestId, string name);
        /// <summary>
        /// Lists the game.
        /// </summary>
        /// <returns>List&lt;System.String&gt;.</returns>
        List<string> ListGame();
        /// <summary>
        /// Plays the game.
        /// </summary>
        /// <param name="clientId">The client identifier.</param>
        /// <returns>MultiPlayerGame.</returns>
        MultiPlayerGame PlayGame(string clientId);
    }
}
